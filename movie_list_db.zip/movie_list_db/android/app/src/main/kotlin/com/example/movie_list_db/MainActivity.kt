package com.example.movie_list_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
