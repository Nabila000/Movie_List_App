import 'package:flutter/material.dart';
import 'package:movie_list_db/pages/movie_list_page.dart';
import 'package:movie_list_db/pages/new_movie_add.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      initialRoute: MovieListPage.routeName,

      routes: {
        MovieListPage.routeName:(context)=>MovieListPage(),
        NewMoveAddPage.routeName:(context)=>NewMoveAddPage(),
      },
    );
  }
}


